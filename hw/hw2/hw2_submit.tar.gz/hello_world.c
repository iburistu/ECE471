#include <stdio.h>

int main(int argc, char **argv) {

    // for loop that prints a number followed by a tab, followed by a space, followed by a newline
    for (int i = 0; i < 15; i++) {
	printf("#%d:\tECE471 HOWDY\n", i + 1);
    }
	return 0;
}
