#define SENSOR_NAME "/sys/bus/w1/devices/28-000008d58b8f/w1_slave"
