#!/bin/sh

# print text with echo
echo "ECE471 is cool!"
